﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LevelFinished : MonoBehaviour {
    public bool levelFinished = false;
    public Image screenCanvas;
    public float fillSpeed = 10;
	// Use this for initialization
	void Start () 
    {

        levelFinished = false;
        screenCanvas = GameObject.Find("ScreenCanvas").GetComponent<Image>();
    }
	
	// Update is called once per frame
	void Update () 
    {
		if(levelFinished == false)
        {
            if (screenCanvas.fillAmount > 0)
            {
                screenCanvas.fillAmount -= fillSpeed * Time.deltaTime;

            }
        }
        else
        {
            if (screenCanvas.fillAmount < 1)
            {
                screenCanvas.fillAmount += fillSpeed * Time.deltaTime;

            }
            if(screenCanvas.fillAmount >= 1)
            {
                if (SceneManager.GetActiveScene().name != "End")
                {
                    SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
                }
                else
                {
                    SceneManager.LoadScene(1);
                }
            }
        }
	}
}
